package model;

public class FreeRoom extends Room{
    public FreeRoom(String roomNumber, Double price, RoomType type) {
        super(roomNumber, price, type);
        this.price = 0.0;
    }

    @Override
    public String toString(){
        return "Here is the room number: " + this.roomNumber + ". The price of the room is: " + this.price + " and it is a: " + type;
    }
}
