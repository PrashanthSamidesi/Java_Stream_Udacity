package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Customer {
    String firstName;
    String lastName;
    String email;
    boolean isValid = false;

    public Customer(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;

        String RegEx = "^(.+)@(.+)\\.(.+)$";
        Pattern pattern = Pattern.compile(RegEx);
        Matcher matcher = pattern.matcher(email);

        if (matcher.matches()) {
            this.email = email;
            isValid = true;
        } else {
            throw new IllegalArgumentException("Please enter a valid email address.");
        }
    }

    @Override
    public String toString() {
        return "First Name: " + firstName + " last Name: " + lastName + " email address: " + email;
    }

}
