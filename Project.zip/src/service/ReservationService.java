package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;
import java.util.regex.Pattern;

public class ReservationService {

    private static ReservationService instance = new ReservationService();

    private ReservationService() {};

    public static ReservationService getInstance(){
        return instance;
    }

    private Map<String, IRoom> rooms = new HashMap<>();

    private Collection<Reservation> reservations = new ArrayList<>();

    // Here we are adding the room
    public void addRoom(IRoom room){
        if(room == null){
            throw new IllegalArgumentException("Room cannot be null.");
        }
        rooms.put(room.getRoomNumber(), room);
    }

    // Here we are getting the room based on the roomID
    public IRoom getARoom(String roomID){
        return rooms.get(roomID);
    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate){
        if(customer == null || room == null || checkInDate == null || checkOutDate == null){
            throw new IllegalArgumentException("Inputs cannot be Null.");
        }
        if(!(rooms.containsKey(room.getRoomNumber()))){
            throw new IllegalArgumentException("Room can't be found. "+ room.getRoomNumber());
        }

        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){
        if(checkInDate == null || checkOutDate == null){
            throw new IllegalArgumentException("Dates can't be null.");
        }

        Collection<IRoom> available = new ArrayList<>();
        for(IRoom room : rooms.values()){
            if(isRoomAvailable(room, checkInDate, checkOutDate)){
                available.add(room);
            }
        }
        return available;
    }

    public Collection<Reservation> getCustomersReservations(Customer customer){
        Collection<Reservation> result = new ArrayList<>();

        if(customer == null){
            return result;
        }

        for(Reservation r: reservations){
            if(r.getCustomer().equals(customer)){
                result.add(r);
            }
        }
        return result;
    }

    public void printAllReservations(){
        if (reservations.isEmpty()){
            System.out.println("There are no reservations. ");
        }
        else{
            for(Reservation r : reservations){
                System.out.println(r);
            }
        }
    }

    public Collection<IRoom> getAllRooms(){
        return rooms.values();
    }
    private boolean isRoomAvailable(IRoom room, Date newCheckIn, Date newcheckOut){
        for(Reservation existing : reservations){
            if(!(existing.getRoom().getRoomNumber().equals(room.getRoomNumber()))){
                continue;
            }
            Date existingCheckIn = existing.getCheckInDate();
            Date existingCheckOut = existing.getCheckOutDate();

            if((newCheckIn.compareTo(existingCheckIn) <= 0) || newcheckOut.compareTo(existingCheckOut) >= 0){
                continue;
            }
            else{
                return false;
            }
        }
        return true;
    }

}
